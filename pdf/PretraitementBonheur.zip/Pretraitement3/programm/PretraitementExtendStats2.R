# Supprimer toutes les variables pour retester le code si on l'a déjà lancé une fois

rm(list = ls())

### 1. Installation des bibliothèques et du répertoire de travail 

setwd("TonDossierCourant")

.libPaths("Packages")

# install.packages("readxl")
# install.packages("dplyr")
# install.packages("writexl")
# install.packages("ggplot2")
# install.packages("RColorBrewer")

library(readxl)
library(dplyr)
library(writexl)




### 2. Chargement et harmonisation des données
excel2023 <- read_excel("data/Data._WHR2023.xls")
excel2024 <- read_excel("data/Data_WHR2024 .xls")
excel_hist <- read_excel("data/Data_WHR2005-2022.xls")


# Ajouter l'année aux nouveaux fichiers
excel2023 <- excel2023 %>%
  mutate(year = 2023)

excel2024 <- excel2024 %>%
  mutate(year = 2024)


# Harmoniser les noms de colonnes similaires entre les fichiers
excel2023 <- excel2023 %>%
  rename(
    "Life Ladder" = "Ladder score",
    "Log GDP per capita" = "Logged GDP per capita",
    "Healthy life expectancy at birth" = "Healthy life expectancy",
    "Freedom to make life choices" = "Freedom to make life choices",
    "Perceptions of corruption" = "Perceptions of corruption"
  )

excel2024 <- excel2024 %>%
  rename(
    "Life Ladder" = "Ladder score"
  )

# Fusion des données historiques et récentes

final_data <- bind_rows(excel_hist, excel2023, excel2024)


# Afficher les premières lignes du fichier fusionné
head(final_data)




### 4. Création de la variable Continent 

# Fusion avec la table de correspondance Pays-Continent

# Charger la table de correspondance
country_continent_mapping <- read_excel("data/PaysContinents.xlsx")


# Corriger les noms des pays dans la colonne 'Nom anglais' pour réussir la jointure sur le nom des pays

country_continent_mapping <- country_continent_mapping %>%
  mutate(
    `Nom anglais` = case_when(
      `Nom anglais` == "United States of America" ~ "united states",
      `Nom anglais` == "United Kingdom of Great Britain and Northern Ireland" ~ "united kingdom",
      `Nom anglais` == "Taiwan (Province of China)" ~ "taiwan province of china",
      `Nom anglais` == "Korea (the Democratic People's Republic of)" ~ "south korea",
      `Nom anglais` == "Moldova (the Republic of)" ~ "moldova",
      `Nom anglais` == "Viet Nam" ~ "vietnam",
      `Nom anglais` == "Bolivia (Plurinational State of)" ~ "bolivia",
      `Nom anglais` == "Russian Federation" ~ "russia",
      `Nom anglais` == "Hong Kong" ~ "hong kong s.a.r. of china",
      `Nom anglais` == "Congo" ~ "congo (brazzaville)",
      `Nom anglais` == "Venezuela (Bolivarian Republic of)" ~ "venezuela",
      `Nom anglais` == "Lao People's Democratic Republic" ~ "laos",
      `Nom anglais` == "Palestine, State of" ~ "state of palestine",
      `Nom anglais` == "Iran (Islamic Republic of)" ~ "iran",
      `Nom anglais` == "Turkey" ~ "turkiye",
      `Nom anglais` == "Tanzania, the United Republic of" ~ "tanzania",
      `Nom anglais` == "Congo (the Democratic Republic of the)" ~ "congo (kinshasa)",
      `Nom anglais` == "Syrian Arab Republic" ~ "syria",
      `Nom anglais` == "Central Afriquen Republic" ~ "central african republic", 
      `Nom anglais` == "Côte d'Ivoire" ~ "ivory coast",
      TRUE ~ `Nom anglais`  # Garder le nom en anglais de départ sinon
    )
  )


# Normalisation des colonnes textuelles

# Uniformiser la casse pour 'Country name'
final_data <- final_data %>%
  mutate(`Country name` = tolower(`Country name`))


# la casse pour 'Nom anglais'
country_continent_mapping <- country_continent_mapping %>%
  mutate(`Nom anglais` = tolower(`Nom anglais`))



# Fusionner les deux fichiers en utilisant le nom anglais des pays comme clé
final_data <- final_data %>%
  left_join(country_continent_mapping, by = c("Country name" = "Nom anglais"))


### 5. Nettoyage des données 


### Statistiques des données pour savoir ce qu'on doit nettoyer


# Dimensions (nombre de lignes et colonnes)
dim(final_data)     

# Afficher la structure du dataset
str(final_data)

# Vérifier les types de données actuels
sapply(final_data, class)

# Compter les valeurs manquantes par colonne
colSums(is.na(final_data))


## Conversion textuelle en facteur pour les variables qualitatives

final_data$`Country name` <- as.factor(final_data$`Country name`)
final_data$Continent <- as.factor(final_data$Continent)


# Identifier les colonnes numériques
numeric_cols <- colnames(final_data)[sapply(final_data, is.numeric)]


### Gestion des NA

# Calculer la proportion de NA pour chaque colonne
na_proportions <- colSums(is.na(final_data)) / nrow(final_data)

# Afficher les proportions de NA pour chaque colonne
print("Proportions de NA pour chaque colonne :")
print(na_proportions)


# Étape 1 : Traiter les colonnes avec entre 0% et 15% de NA (imputation par groupe)

columns_to_group_impute <- names(na_proportions)[na_proportions <= 0.15]
if (length(columns_to_group_impute) > 0) {
  for (col in columns_to_group_impute) {
    # Vérifie si la colonne est numérique avant de continuer
    if (col %in% numeric_cols) {
      for (country in unique(final_data$`Country name`)) {
        # Sélectionne les valeurs de la colonne pour le pays donné
        country_values <- final_data[final_data$`Country name` == country, col]
        
        # Vérifie s'il existe des données valides (non NA et numériques)
        if (is.numeric(country_values) ) {
          # Calcule la médiane en ignorant les valeurs manquantes
          country_median <- median(country_values, na.rm = TRUE)
          
          # Remplace les valeurs NA par la médiane du pays
          final_data[final_data$`Country name` == country & is.na(final_data[[col]]), col] <- country_median
          
        }
      }
      global_median <- median(final_data[[col]], na.rm = TRUE)
      final_data[is.na(final_data[[col]]), col] <- global_median
    }
  }
}




# Étape 2 : Traiter les colonnes avec plus de 15% de NA
columns_to_remove <- names(na_proportions)[na_proportions > 0.15]
final_data <- final_data[, !(names(final_data) %in% columns_to_remove)]

# Normalisation des noms de colonnes
names(final_data) <- make.names(names(final_data), unique = TRUE)

# Traiter les doublons
final_data <- distinct(final_data)


### 6. Création de nouvelle variables quantitatives

# Calculer le Ratio Affectif
final_data$affect_ratio <- final_data$`Positive.affect` / final_data$`Negative.affect`


# Calculer le Taux de Croissance du PIB
final_data <- final_data %>%
  arrange(Country.name, year) %>%
  group_by(Country.name) %>%
  mutate(gdp_growth_rate = (`Log.GDP.per.capita` - lag(`Log.GDP.per.capita`)) / lag(`Log.GDP.per.capita`)) %>%
  ungroup()



### 7. recodage pour des données par classe dans un autre fichier 




# Créer des classes pour Life.Ladder
final_data$life_ladder_class <- cut(final_data$`Life.Ladder`,
                                    breaks = c(1, 3, 4, 6, 7, 7.5, 8.1),
                                    labels = c("Très bas [1-3)", "Bas [3-4)", "Moyen [4-6)", "Élevé [6-7)", "Très élevé [7-7.5)", "Exceptionnel [7.5-8.1]"),
                                    include.lowest = TRUE,
                                    right = FALSE)


# Créer des classes pour Log.GDP.per.capita
final_data$log_gdp_class <- cut(final_data$`Log.GDP.per.capita`,
                                breaks = c(5,seq(7, 12, by = 1)),
                                labels = c("Faible [5-7)", "Moyen [7-8)", "Moyennement Élevé [8-9)", "élevé [9-10)", "Très élevé [10-11)", "Extrêmement élevé [11-12]"),
                                include.lowest = TRUE,
                                right = FALSE)


# Créer des classes pour Social.support
final_data$social_support_class <- cut(final_data$`Social.support`,
                                       breaks = seq(0.2, 1, by = 0.1),
                                       labels = c("Très faible [0.2-0.3)", "Faible [0.3-0.4)", "Modéré [0.4-0.5)", "Bon [0.5-0.6)", "Très bon [0.6-0.7)", "Extrèmement bon [0.7-0.8)", "Exceptionnellement bon [0.8-0.9)", " Parfaitement bon[0.9-1]"),
                                       include.lowest = TRUE,
                                       right = FALSE)




# Créer des classes pour Healthy.life.expectancy.at.birth
final_data$healthy_life_expectancy_class <- cut(final_data$`Healthy.life.expectancy.at.birth`,
                                                breaks = c(0, 50, 55, 60, 65, 70, 75, 80),
                                                labels = c("Très court [0-50)", "Court [50-55)", "Moyen [55-60)", "Long [60-65)", "Très long [65-70)", "Extrêmement long [70-75)", "Exceptionnel [75-80]"),
                                                include.lowest = TRUE,
                                                right = FALSE)





# Créer des classes pour Freedom.to.make.life.choices
final_data$freedom_life_choices_class <- cut(final_data$`Freedom.to.make.life.choices`,
                                             breaks = c(0, 0.5, 0.6, 0.7, 0.8, 0.9, 1),
                                             labels = c("Aucune liberté [0-0.5)", "Très limitée [0.5-0.6)", "Limitée [0.6-0.7)", "Modérée [0.7-0.8)", "Considérable [0.8-0.9)", "Totale [0.9-1]"),
                                             include.lowest = TRUE,
                                             right = FALSE)




# Créer des classes pour Generosity
final_data$Generosity_class <- cut(final_data$Generosity,
                                   breaks = c(-0.4,seq(-0.25, 0.25, by = 0.1),0.56), 
                                   labels = c("Très égoïste [-0.4- -0.25)", "Égoïste [-0.25- -0.15)", "Peu généreux [-0.15- -0.05)", "Neutre [-0.05- 0.05)", "Généreux [0.05- 0.15)", "Très généreux [0.15- 0.25)", "Exceptionnellement généreux [0.25- 0.4]"),
                                   include.lowest = TRUE,
                                   right = FALSE)




# Créer des classes pour Perceptions.of.corruption
final_data$perceptions_corruption_class <- cut(final_data$`Perceptions.of.corruption`,
                                               breaks = seq(0, 1, by = 0.1),
                                               labels = c("Extrèmement faible [0-0.1)", "Très Faible [0.1-0.2)", "Faible[0.2-0.3)", "Modéré [0.3-0.4)", "Moyennement élevé [0.4-0.5)", "élevé [0.5-0.6)", "Très élevé [0.6-0.7)", "Extrèmement élevé [0.7-0.8)", "Critique [0.8-0.9)", "Catastrophique [0.9-1]"),
                                               include.lowest = TRUE,
                                               right = FALSE)




# Créer des classes pour Positive.affect
final_data$positive_affect_class <- cut(final_data$`Positive.affect`,
                                        breaks = c(0, 0.35, 0.45, 0.55, 0.65, 0.75, 0.85, 0.95, 1),
                                        labels = c("Nul [0-0.35)", "Très faible [0.35-0.45)", "Faible [0.45-0.55)", "Modéré [0.55-0.65)", "Bon [0.65-0.75)", "Très bon [0.75-0.85)", "Excellent [0.85-0.95)", "Exceptionnel [0.95-1]"),
                                        include.lowest = TRUE,
                                        right = FALSE)




# Créer des classes pour Negative.affect
final_data$negative_affect_class <- cut(final_data$`Negative.affect`,
                                        breaks = c(0, seq(0.1, 0.6, by = 0.1), 0.71),
                                        labels = c("Nul [0-0.1)", "Très faible [0.1-0.2)", "Faible [0.2-0.3)", "Modéré [0.3-0.4)", "Élevé [0.4-0.5)", "Très élevé [0.5-0.6)", "Critique [0.6-0.71]"),
                                        include.lowest = TRUE,
                                        right = FALSE)



# Créer des classes pour affect_ratio
final_data$affect_ratio_class <- cut(final_data$affect_ratio,
                                     breaks = seq(0, 10, by = 1),
                                     labels = c("Très négatif [0-1)", "Négatif [1-2)", "Neutre [2-3)", "Positif [3-4)", "Très positif [4-5)", "Extrêmement positif [5-6)", "Optimiste [6-7)","Très Optimiste [7-8)","Extrèmement Optimiste [8-9)", "Exceptionnellement optimiste [9-10]"),
                                     include.lowest = TRUE,
                                     right = FALSE)



# Créer des classes pour gdp_growth_rate
final_data$gdp_growth_rate_class <- cut(final_data$gdp_growth_rate,
                                        breaks = c(-0.42, -0.2, -0.1, 0.1, 0.15, 0.2, 0.72),
                                        labels = c("Récession sévère [-0.4--0.2)",
                                                   "Récession [-0.2--0.1)",
                                                   "Stagnation [-0.1-0.1)",
                                                   "Croissance modérée [0.1-0.15)",
                                                   "Croissance forte [0.15-0.2)",
                                                   "Croissance exceptionnelle [0.2-0.72]"),
                                        include.lowest = TRUE,
                                        right = FALSE)




#8. Sélectionner uniquement les colonnes de type factor





final_data_classes <- final_data %>%
  select(c(where(is.factor), year))


final_raw_data <- final_data %>%
  select(-matches("class$"))

## Echantillon definitif


# Étape 1 : Identifier les pays ayant participé toutes les années entre 2018 et 2024
countries_with_complete_years <- final_raw_data %>%
  filter(year >= 2018, year <= 2024) %>%
  group_by(Country.name) %>%
  summarise(years_participated = n_distinct(year)) %>%
  filter(years_participated == 7) # 7 années

# Étape 2 : Filtrer toutes les colonnes pour les pays sélectionnés
final_raw_data <- final_raw_data %>%
  filter(Country.name %in% countries_with_complete_years$Country.name & between(year, 2018, 2024)) %>%
  select(everything()) # Conserver toutes les variables

final_data_classes <- final_data_classes %>%
  filter(Country.name %in% countries_with_complete_years$Country.name & between(year, 2018, 2024)) %>%
  select(everything()) # Conserver toutes les variables


#9 Enregistrement du dataframe sans classes et avec classe dans des fichiers xlsx 

# Vérification


sapply(final_data_classes, class)
colSums(is.na(final_data_classes))
summary(final_data_classes)


# Sauvegarder le fichier avec les classes
write_xlsx(final_data_classes, "output/final_data_classes.xlsx")



# Vérification


sapply(final_raw_data, class)
colSums(is.na(final_raw_data))
summary(final_raw_data)



### Dataset nettoyé avec que des données brutes

write_xlsx(final_raw_data, "output/final_raw_data.xlsx")







###################################### Analyses statistiques ##################################################


# Analyse univariee

# Analyses en classe = donnees groupees


library(ggplot2)

for (var in names(final_data_classes)) {
  if (is.factor(final_data_classes[[var]]) && var != "Country.name") {
    print(
      ggplot(final_data_classes, aes_string(x = var)) +
        geom_bar(fill = "steelblue") +
        theme_minimal() +
        labs(title = paste("Distribution de", var))
    )
  }
}






# Analyses a partir de donnees brutes



for (var in names(final_raw_data)) {
  if (is.numeric(final_raw_data[[var]]) && var != "year") {
    print(
      ggplot(final_raw_data, aes_string(y = var)) +
        geom_boxplot(fill = "steelblue", color = "black", outlier.color = "red", outlier.shape = 16) +
        theme_minimal() +
        labs(title = paste("Boîte à moustaches de", var), y = var)
    )
  }
}


# compter les valeurs hors des bornes pour chaque variable numérique
for (col in names(final_raw_data)) {
  if (is.numeric(final_raw_data[[col]])) {
    Q1 <- quantile(final_raw_data[[col]], 0.25, na.rm = TRUE)
    Q3 <- quantile(final_raw_data[[col]], 0.75, na.rm = TRUE)
    IQR <- Q3 - Q1
    
    moustache_superieure <- Q3 + 1.5 * IQR
    moustache_inferieure <- Q1 - 1.5 * IQR
    
    valeurs_au_dessus <- sum(final_raw_data[[col]] > moustache_superieure, na.rm = TRUE)
    valeurs_en_dessous <- sum(final_raw_data[[col]] < moustache_inferieure, na.rm = TRUE)
    
    cat("Colonne :", col, "\n")
    cat("  Nombre de valeurs au-dessus de la moustache supérieure :", valeurs_au_dessus, "\n")
    cat("  Nombre de valeurs en-dessous de la moustache inférieure :", valeurs_en_dessous, "\n")
  }
}





###############################################################






# Analyses bivariee

############################################################

# A partir de donnees brutes (= final_raw_data)


# Toutes les variables sachant les continents

# Boite a moustache 

for (var in names(final_raw_data)) {
  if (is.numeric(final_raw_data[[var]]) && var != "year") {
    print(
      ggplot(final_raw_data, aes_string(x = "Continent", y = var)) +
        geom_boxplot(fill = "steelblue", color = "black", outlier.color = "red", outlier.shape = 16) +
        theme_minimal() +
        labs(title = paste("Boîte à moustaches de", var, "par continent"), x = "Continent", y = var) +
        theme(axis.text.x = element_text(angle = 45, hjust = 1)) # Rotation des labels pour meilleure lisibilité
    )
  }
}





# Toutes les variables Sachant le PIB par habitant en classe

# Boite a moustache 

for (var in names(final_raw_data)) {
  if (is.numeric(final_raw_data[[var]]) && var != "year") {
    temp_data <- final_raw_data %>%
      left_join(final_data_classes %>% select(Country.name, year, log_gdp_class), 
                by = c("Country.name", "year"))
    
    print(
      ggplot(temp_data, aes_string(x = "log_gdp_class", y = var)) +
        geom_boxplot(fill = "steelblue", color = "black", outlier.color = "red", outlier.shape = 16) +
        theme_minimal() +
        labs(title = paste("Boîte à moustaches de", var, "sachant le PIB habitant"), x = "log_gdp_class", y = var) +
        theme(axis.text.x = element_text(angle = 45, hjust = 1)) # Rotation pour lisibilité
    )
  }
}


# Toutes les variables sachant PIB par habitant (de final_raw_data) par Continent 
# Nuage de point + droit de regression


# Liste des variables numériques à tester sur l'axe Y, sauf "Log.GDP.per.capita" et "year"
variables_y <- names(final_raw_data)[sapply(final_raw_data, is.numeric) & !names(final_raw_data) %in% c("Log.GDP.per.capita", "year")]

# Boucle pour créer et afficher un graphique pour chaque variable Y
for (var in variables_y) {
  print(
    ggplot(final_raw_data, aes_string(x = "Log.GDP.per.capita", y = var, color = "Continent")) +
      geom_point(alpha = 0.6) +
      geom_smooth(method = "lm", se = FALSE, color = "darkgreen") + # Utiliser une autre couleur pour la droite de régression
      labs(
        title = paste("Relation entre PIB par habitant et", var),
        x = "Log(GDP per capita)",
        y = var
      ) +
      theme_minimal()
  )
}




# Toutes les variables Sachant le PIB habitant (de final_raw_data) par annee


# Nuage de point + droite de regression

# Liste des variables numériques à tester sur l'axe Y, sauf "Log.GDP.per.capita" et "year"
variables_y <- names(final_raw_data)[sapply(final_raw_data, is.numeric) & !names(final_raw_data) %in% c("Log.GDP.per.capita", "year")]

# Boucle pour créer et afficher un graphique pour chaque variable Y
for (var in variables_y) {
  for (yr in unique(final_raw_data$year)) { # Parcourir les années
    data_year <- final_raw_data %>% filter(year == yr) # Filtrer les données pour l'année courante
    
    print(
      ggplot(data_year, aes_string(x = "Log.GDP.per.capita", y = var)) +
        geom_point(alpha = 0.6, color = "orange") + # Couleur des points
        geom_smooth(method = "lm", se = FALSE, color = "darkblue") + # Couleur de la droite de régression
        labs(
          title = paste("Nuage de points pour", var, "en", yr, "sachant le PIB par habitant"),
          x = "Log(GDP per capita)",
          y = var
        ) +
        theme_minimal()
    )
  }
}





########################################

#test ficher entre la variable continent et les autres variables 


for (var in names(final_raw_data)) {
  if (is.numeric(final_raw_data[[var]]) && var != "year") {
    # Réalisation du test de Fisher (ANOVA)
    anova_result <- aov(as.formula(paste(var, "~ Continent")), data = final_raw_data)
    p_value <- summary(anova_result)[[1]]["Pr(>F)"][1]
    
    # Affichage du résultat
    print(paste("Variable:", var, p_value))
  }
}



####################################

# Test ficher entre toutes les variables de final_raw_data  expliquees par log_gdp_class

for (var in names(final_raw_data)) {
  if (is.numeric(final_raw_data[[var]]) && var != "year") {
    temp_data <- final_raw_data %>%
      left_join(final_data_classes %>% select(Country.name, year, log_gdp_class), 
                by = c("Country.name", "year"))
    
    # Réalisation du test de Fisher (ANOVA)
    anova_result <- aov(as.formula(paste(var, "~ log_gdp_class")), data = temp_data)
    p_value <- summary(anova_result)[[1]]["Pr(>F)"][1]
    print(paste("Variable:", var, p_value))
  }
}


#############################################


#Test de correlation Pearson entre toutes les variables quantitatives (final_raw_data) et la variable log_gdp (final_raw_data) 

for (var in names(final_raw_data)) {
  if (is.numeric(final_raw_data[[var]]) && var != "year") {
    # Test de corrélation de Pearson entre la variable et "PIB"
    cor_result <- cor.test(final_raw_data[[var]], final_raw_data$Log.GDP.per.capita, method = "pearson")
    p_value <- cor_result$p.value
    
    # Affichage du résultat
    print(paste("Variable:", var, "- p-value:", p_value))
  }
}








###########################################################





# A partir de donnees groupees (= final_data_classes)


# toutes les variables Sachant le PIB par habitant en classe
# Diagramme en barre empilees

library(RColorBrewer)



# Fonction pour générer une palette aléatoire avec un contraste clair-foncé
generer_palette_couleurs <- function(num_levels) {
  # Couleur de base aléatoire (claire)
  base_color <- rgb(runif(1, 0.6, 1), runif(1, 0.6, 1), runif(1, 0.6, 1))
  # Couleur finale aléatoire (plus foncée)
  dark_color <- rgb(runif(1, 0, 0.4), runif(1, 0, 0.4), runif(1, 0, 0.4))
  # Génération de la palette
  colorRampPalette(c(base_color, dark_color))(num_levels)
}

for (var in names(final_data_classes)) {
  if (is.factor(final_data_classes[[var]]) && var != "log_gdp_class" && var != "year") {
    temp_data <- final_data_classes %>%
      count(log_gdp_class, !!sym(var), .drop = FALSE) %>%
      group_by(log_gdp_class) %>%
      mutate(Proportion = n / sum(n)) %>%
      ungroup()
    
    # Nombre de modalités dans la variable
    num_levels <- length(levels(final_data_classes[[var]]))
    
    # Génère une palette aléatoire pour ce graphique
    random_palette <- generer_palette_couleurs(num_levels)
    
    # Vérifie que temp_data n'est pas vide avant de créer le graphique
    if (nrow(temp_data) > 0) {
      print(
        ggplot(temp_data, aes(x = log_gdp_class, fill = !!sym(var), y = Proportion)) +
          geom_bar(stat = "identity", position = position_fill(reverse = TRUE), color = "black") +
          scale_fill_manual(
            values = random_palette, 
            guide = guide_legend(reverse = TRUE)  # Inversion de la légende
          ) +
          theme_minimal() +
          labs(
            title = paste("Distribution conditionnelle de", var, "par PIB habitant"), 
            x = "log_gdp_class", 
            y = "Proportion relative"
          ) +
          theme(axis.text.x = element_text(angle = 45, hjust = 1)) # Rotation pour lisibilité
      )
    } 
  }
}



# Toutes les variables Sachant continent 
# Diagramme en barre empilees



for (var in names(final_data_classes)) {
  if (is.factor(final_data_classes[[var]]) && var != "Continent" && var != "year") {
    temp_data <- final_data_classes %>%
      count(Continent, !!sym(var), .drop = FALSE) %>%
      group_by(Continent) %>%
      mutate(Proportion = n / sum(n)) %>%
      ungroup()
    
    # Nombre de modalités dans la variable
    num_levels <- length(levels(final_data_classes[[var]]))
    
    # Génère une palette aléatoire pour ce graphique
    random_palette <- generer_palette_couleurs(num_levels)
    
    # Vérifie que temp_data n'est pas vide avant de créer le graphique
    if (nrow(temp_data) > 0) {
      print(
        ggplot(temp_data, aes(x = Continent, fill = !!sym(var), y = Proportion)) +
          geom_bar(stat = "identity", position = position_fill(reverse = TRUE), color = "black") +
          scale_fill_manual(
            values = random_palette, 
            guide = guide_legend(reverse = TRUE)  # Inversion de la légende
          ) +
          theme_minimal() +
          labs(
            title = paste("Distribution conditionnelle de", var, "par Continent"), 
            x = "Continent", 
            y = "Proportion relative"
          ) +
          theme(axis.text.x = element_text(angle = 45, hjust = 1)) # Rotation pour lisibilité
      )
    } 
  }
}


#######################################################


# test du chi2 entre toutes les variables qualitatives (factor) avec Continent


variables <- names(final_data_classes)[sapply(final_data_classes, is.factor)]

# Test du Khi2 pour chaque variable par rapport au continent
for (var in variables) {
  cat("\nTest du Khi2 entre 'Continent' et '", var, "' :\n", sep="")
  
  # Construction du tableau de contingence
  contingency_table <- table(final_data_classes$Continent, final_data_classes[[var]])
  
  # Appliquer le test du khi-deux
  test_result <- chisq.test(contingency_table)
  
  # Affichage du résultat
  print(test_result)
}


##################################

# test du chi2 entre toutes les variables qualitatives (factor) avec PIB par habitant en classe


variables <- names(final_data_classes)[sapply(final_data_classes, is.factor)]



# Test du Khi2 pour chaque variable par rapport à "log_gdp_class"
for (var in variables) {
  cat("\nTest du Khi2 entre 'log_gdp_class' et '", var, "' :\n", sep="")
  
  # Construction du tableau de contingence
  contingency_table <- table(final_data_classes$log_gdp_class, final_data_classes[[var]])
  
  # Appliquer le test du khi-deux
  test_result <- chisq.test(contingency_table)
  
  # Affichage du résultat
  print(test_result)
}







