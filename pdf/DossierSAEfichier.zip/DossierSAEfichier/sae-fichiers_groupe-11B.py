#SAE FICHIER AIT ZAOUIT RIDA    CHEN ENZO   GROUPE 11B

f = open("groupe-11B_data.txt", mode = "r", encoding = "utf-8")
texte = f.read()


#LISTE1 : Premiere split séparant chaque enregistrement
liste1 = texte.split("&&")
liste1[0]= liste1[0][1:]            #Retire le premier &
liste1[-1] = liste1[-1][0:-1]       #Retire le dernier &


# LISTE2 : Deuxième split séparant chaque attribut d'un enregistrement
# Et REGLE LE PROBLEME DES DESCRIPTIONS SUR LES VIRGULES
liste2 = []
for enregistrement in liste1:
    a = enregistrement.split(",")
    for i in range(len(a)):
        if 'desc=' in a[i]: 
            j = i
            while j+1 <= len(a)-1:
                j += 1
                a[i] = a[i] + "," + a[j]
                a[j] = ''
    liste2.append(a)
    
    
#Troisième séparation sur chaque attribut en séparant la cle, le séparateur et la valeur
for i in range(len(liste2)): 
    for j in range(len(liste2[i])):
        cle, sep, val = liste2[i][j].partition('=')
        liste2[i][j] = [cle,sep,val]


#CONSTRUCTION LISTE FINALE: Liste2 version améliorée avec les titres et les restrictions en majuscule,
#retire les espaces inutiles et les listes vides de la liste2, ajoute l'attribut référence, réalise les conversions des types demandés...


#INITIALISATION DE LA LISTE FINALE 
liste_finale = []
for _ in range(len(liste2)):
    listeTmp = []
    for _ in range(8):
          listeTmp.append([0, "=", 0])
    liste_finale.append(listeTmp)

#AJOUT DE L'ATTRIBUT REFERENCE DANS LISTE FINALE
for i in range(len(liste_finale)):
        liste_finale[i][0][0] = "ref"
        liste_finale[i][0][2] = "F-11B" + str(i) +"-"+ str(int(float(liste2[i][2][2])))
  
#AJOUT DE TOUS LES AUTRES ATTRIBUTS EN RESPECTANT LES CONTRAINTES DEMANDEES 
for i in range(len(liste2)):
    for j in range(len(liste2[i])):
        
        if liste2[i][j][0] == "title":
            liste_finale[i][1] = liste2[i][j]
            liste_finale[i][1][2] = liste_finale[i][1][2].title().strip()
        
        elif liste2[i][j][0] == "year":
            liste_finale[i][2] = liste2[i][j]
            if liste_finale[i][2][2] != "":
                liste_finale[i][2][2] = str(int(float(liste_finale[i][2][2])))
                
        elif liste2[i][j][0] == "duration":
            liste_finale[i][3] = liste2[i][j]
            if liste_finale[i][3][2] != "":
                liste_finale[i][3][2] = str(int(float(liste_finale[i][3][2])))

        elif liste2[i][j][0] == "nbvotes":
            liste_finale[i][4] = liste2[i][j]
            if liste_finale[i][4][2] != "":
                liste_finale[i][4][2] = str(int(liste_finale[i][4][2]))
        
        elif liste2[i][j][0] == "score":
            liste_finale[i][5] = liste2[i][j]
            if liste_finale[i][5][2] != "":
                liste_finale[i][5][2] = str(float(liste_finale[i][5][2]))
        
        elif liste2[i][j][0] == "restriction":
            liste_finale[i][6] = liste2[i][j]
            if liste_finale[i][6][2] != "":
                liste_finale[i][6][2] = liste_finale[i][6][2].title().strip()
        
        elif liste2[i][j][0] == "desc":
            liste_finale[i][7] = liste2[i][j]
            if liste_finale[i][7][2] != "":
                liste_finale[i][7][2] = liste_finale[i][7][2].strip()

#construction liste_cle 
liste_cle = ["Référence", "Titre", "Année", "Durée (min)", "Nombre de votes", "Score", "Restriction","Description"]      

#Construction liste_valeur
liste_valeur = []

for i in range(len(liste_finale)):
    liste_valeur_ligne = []
    for j in range(len(liste_finale[i])):
        liste_valeur_ligne.append(liste_finale[i][j][2])
    liste_valeur.append(liste_valeur_ligne)

#Construction cle_formatcsv  PREMIERE LIGNE DU FICHIER CSV
cle_formatcsv = ";".join(liste_cle)

#Construction val_formatcsv   REPRESENTANT CHAQUE ENREGISTREMENT PAR LIGNE
valeur_formatcsv = ""
for i in range(len(liste_valeur)):
    ligne = ";".join(liste_valeur[i])
    valeur_formatcsv = valeur_formatcsv +ligne+"\n"

# Data correspondant au texte csv      PREMIERE LIGNE DU FICHIER CSV + TOUTES LES LIGNES D'ENREGISTREMENT DU FICHIER CSV
data = cle_formatcsv + "\n" +valeur_formatcsv
f = open("groupe-11B_data.csv", mode = "w", encoding = "cp1252")
f.write(data)
f.close()



#FICHIER2
f = open("groupe-11B_info.txt", mode = "w", encoding = "cp1252")
#CHERCHER LE SCORE MINIMUM
score_min = float(liste_valeur[0][5])
for i in range(len(liste_valeur)):
    if score_min > float(liste_valeur[i][5]): 
        score_min = float(liste_valeur[i][5])
#CHERCHER LE SCORE MAXIMUM
score_max = float(liste_valeur[0][5])
for i in range(len(liste_valeur)):
    if score_max < float(liste_valeur[i][5]): 
        score_max = float(liste_valeur[i][5])
#CALCULER LA MOYENNE DES SCORES
somme_score = 0
for i in range(len(liste_valeur)):
    somme_score += float(liste_valeur[i][5])
score_moyen = somme_score/len(liste_valeur) 

#FABRICATION DU TEXTE 
texteInfo = "Nom du fichier : groupe-11B_info.txt\nNombre de films : " + str(len(liste_finale)) + "\nScore minimum : " + str(round(score_min,2)) + "\nScore maximum : " + str(round(score_max,2)) + "\nScore moyen : " + str(round(score_moyen,2))  
f.write(texteInfo)
f.close()

