/* LIBNAME DONNEES "/home/u64203549/BUT SD/2�me ann�e/SAE_domaine_app_v2/FichierConsigne"; */

%MACRO Macro_Principale(
    Chemin=,
    NomFichier=, 
    Onglet=,
    ParametreSemaine=,
    Perimetre=,
    Frequence=
);

    /* Importation du tableau de pilotage avec filtres */
    PROC IMPORT DATAFILE="&Chemin./&NomFichier..xlsx"
               OUT=info (WHERE=(
                    UPCASE('CRITERES RETOUR INITIAL'n) NE 'STOP'
                    AND (%DO i=1 %TO %SYSFUNC(COUNTW(&Frequence., %STR( )));
                            UPCASE(frequence)="%UPCASE(%SCAN(&Frequence., &i., %STR( )))"
                            %IF &i < %SYSFUNC(COUNTW(&Frequence., %STR( ))) %THEN OR;
                         %END;)
                    AND (%DO i=1 %TO %SYSFUNC(COUNTW(&Perimetre., %STR( )));
                            UPCASE(perimetre)="%UPCASE(%SCAN(&Perimetre., &i., %STR( )))"
                            %IF &i < %SYSFUNC(COUNTW(&Perimetre., %STR( ))) %THEN OR;
                         %END;)
                ))
               DBMS=XLSX REPLACE;
               SHEET="&Onglet.";
    RUN;

    /* D�finition des p�riodes bas�es sur la date de soutenance 21/11/2025 */
    DATA _NULL_;
        CALL SYMPUTX('Date_FinStr', PUT(intnx('week', "21NOV2025"d, 0, 'BEGIN'), ddmmyyd10.));
        CALL SYMPUTX('Date_DebutStr', PUT(intnx('week', "21NOV2025"d, &ParametreSemaine., 'BEGIN') + 1, ddmmyyd10.));
        
        CALL SYMPUTX('Date_Fin', intnx('week', "21NOV2025"d, 0, 'BEGIN'));
        CALL SYMPUTX('Date_Debut', intnx('week', "21NOV2025"d, &ParametreSemaine., 'BEGIN') + 1);
    RUN;
    %PUT Borne sup�rieure INT: &Date_Fin;
    %PUT Borne inf�rieure INT: &Date_Debut;
    %PUT Borne sup�rieure STR: &Date_FinStr;
    %PUT Borne inf�rieure STR: &Date_DebutStr;
	
    /* Stocker chaque variable du tableau de pilotage dans des macros variables */
    DATA _NULL_;
        SET info END = fin;
        CALL SYMPUTX(CATS('Fichier',_N_), FICHIER);
        CALL SYMPUTX(CATS('NomPrgmSAS',_N_), NomPrgmSAS);
        CALL SYMPUTX(CATS('Repertoire',_N_), REPERTOIRE);
        CALL SYMPUTX(CATS('Cible',_N_), CIBLE);
/*        CALL SYMPUTX(CATS('Perimetre',_N_), Perimetre);*/
        IF fin = 1 THEN CALL SYMPUTX('NbTotal', _N_);
    RUN;    
    
   
    /* Ex�cution de chaque programme s�lectionn� */
    %DO i=1 %TO &NbTotal.;
        
        %PUT === Ex�cution du programme &&Fichier&i.. ===;
        %PUT R�pertoire: &&Repertoire&i..;
        %PUT Cible: &&Cible&i..;
        
        %INCLUDE "&Chemin./&&Fichier&i...sas";
        
        %&&NomPrgmSAS&i..

        
	%END;

%MEND;
   
%Macro_Principale(
    Chemin= Z:\IUT SD 2�me ann�e\SAE_domaine_app_v4 ,
    NomFichier= TableauPilotageSAE2025v4 , 
    Onglet= Feuil1 ,
    ParametreSemaine=-2,
    Perimetre = EDD,
    Frequence= Hebdo);
    
    