/* LIBNAME DONNEES "/home/u64203549/BUT SD/2�me ann�e/SAE_domaine_app_v3";   */
/* le path qui te rend au dossier o� il y a toutes les table de donn�es : CNR EDD   pour notre cas on utilise 4donnees */
%MACRO SOMME;

	LIBNAME DONNEES "&Chemin.";
	DATA donnees;
/*		SET DONNEES.&Perimetre.;*/
		SET DONNEES.donnees;
	RUN;	
	
	PROC SQL NOPRINT;
	CREATE TABLE Table_SOMME AS
		SELECT SUM(MNT_RESTANT_A_SOLDER) AS SommeSoldeRestant
		FROM donnees
		WHERE date_survenance BETWEEN &Date_Debut. AND &Date_Fin.;
	QUIT;
	
	PROC EXPORT DATA = Table_SOMME
	    OUTFILE="&&Repertoire&i../&&Cible&i..xlsx"
	    DBMS=XLSX
	    REPLACE;
	RUN;
%MEND;


/*%SOMME(Chemin = Z:\IUT SD 2�me ann�e\SAE_domaine_app_v3,*/
/*	   Date_Debut = "3NOV2025"d,*/
/*	   Date_Fin = "16NOV2025"d,*/
/*	   Cible = tableSOMMEv3,*/
/*	   Repertoire = Z:\IUT SD 2�me ann�e\SAE_domaine_app_v3\ResultatDraft*/
/*	   )*/


/*%SOMME(Chemin = Z:\IUT SD 2�me ann�e\SAE_domaine_app_v3,*/
/*	   Date_Debut = "3NOV2025"d,*/
/*	   Date_Fin = "16NOV2025"d,*/
/*	   Cible = tableSOMMEv3,*/
/*	   Repertoire = Z:\IUT SD 2�me ann�e\SAE_domaine_app_v3\ResultatDraft,*/
/*	   Perimetre = donnees)*/

