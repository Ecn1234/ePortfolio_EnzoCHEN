/* LIBNAME DONNEES "/home/u64203549/BUT SD/2�me ann�e/SAE_domaine_app_v3"; /*Question : Est ce que le libname c'est le parametre r�pertoire */


%MACRO MOYENNE;

	LIBNAME DONNEES "&Chemin.";
	DATA donnees;
/*		SET DONNEES.&Perimetre.;*/
		SET DONNEES.donnees;
	RUN;			 

	PROC SQL;
	  CREATE TABLE DecesNotNull AS 
		  SELECT YRDIF(DATEPART(DT_NAISSANCE), DATEPART(DT_DECES), 'AGE') AS age_annees
		  FROM donnees
		  WHERE (DT_DECES IS NOT NULL AND DT_NAISSANCE IS NOT NULL) /*Pr�requis pour calculer l'�ge, une date de d�c�s et une date de naissance*/
		  		AND( 
		  		(DATEPART(DT_NAISSANCE) BETWEEN &Date_Debut. AND &Date_Fin.)					   /* premiere cas avoir une date naissance  dans la p�riode */
		  		 OR (DATEPART(DT_DECES) BETWEEN &Date_Debut. AND &Date_Fin.)   					   /* deuxi�me cas avoir une date d�c�s dans la p�riode */
		  		 OR (DATEPART(DT_NAISSANCE) <=  &Date_Debut. AND DATEPART(DT_DECES) >= &Date_Fin.) /* troisi�me cas avoir la date naissance et la date d�c�s en dehors de la p�riode */
		  		 );
  		
	  CREATE TABLE DecesNull AS 
		  SELECT YRDIF(DATEPART(DT_NAISSANCE), TODAY(), 'AGE') AS age_annees
		  FROM donnees
		  
		  WHERE (DT_NAISSANCE IS NOT NULL AND DT_DECES IS NULL) /*Pr�requis pour calculer l'�ge, une date de d�c�s nulle (Utilisation de "21NOV2025"d ) et une date de naissance*/
				AND( 
			     (DATEPART(DT_NAISSANCE) BETWEEN &Date_Debut. AND &Date_Fin.)/* premiere cas avoir une date naissance  dans la p�riode */
			  	  OR (TODAY() BETWEEN &Date_Debut. AND &Date_Fin.)   		 /* deuxi�me cas avoir la date d'aujourd'hui ("21NOV2025"d) dans la p�riode */
			  	  OR (TODAY() <=  &Date_Debut. AND TODAY() >= &Date_Fin.)  	 /* troisi�me cas avoir la date naissance et la date d'aujourd'hui ("21NOV2025"d) en dehors de la p�riode */
			  	  );
	QUIT;
	
	DATA Age;
		SET DecesNotNull DecesNull;
	RUN;
	
	
	PROC SQL;
		CREATE  TABLE Table_MOYENNE AS
		SELECT MEAN(age_annees) AS Moyenne_Age_Ann�es
		FROM Age;
	QUIT;
	

	PROC EXPORT DATA = Table_MOYENNE
	    OUTFILE="&&Repertoire&i../&&Cible&i..xlsx"
	    DBMS=XLSX
	    REPLACE;
	RUN;
	
	
%MEND;


  
/*%MOYENNE(*/
/*	   Chemin = Z:\IUT SD 2�me ann�e\SAE_domaine_app_v3,*/
/*	   Date_Debut = "12SEP2025"d,*/
/*	   Date_Fin = "16NOV2025"d,*/
/*	   Cible = tableMOYENNEv3,*/
/*	   Repertoire = Z:\IUT SD 2�me ann�e\SAE_domaine_app_v3\ResultatDraft*/
/*		);*/





/* TEST1 */
/*  */
/*%MOYENNE(*/
/*	   Chemin = Z:\IUT SD 2�me ann�e\SAE_domaine_app_v3,*/
/*	   Date_Debut = "12SEP2025"d,*/
/*	   Date_Fin = "16NOV2025"d,*/
/*	   Cible = tableMOYENNEv3,*/
/*	   Repertoire = Z:\IUT SD 2�me ann�e\SAE_domaine_app_v3\ResultatDraft,*/
/*	   Perimetre =  donnees);*/


/* TEST2 */

/* %MOYENNE(Date_Debut = "3NOV2025"d, */
/* 	   Date_Fin = "16NOV2025"d, */
/* 	   Cible = tableMOYENNEv3, */
/* 	   Repertoire = /home/u64203549/BUT SD/2�me ann�e/SAE_domaine_app_v3/ResultatDraft, */
/* 	   Perimetre =  donnees); */



/* 		  SELECT DATEPART(DT_NAISSANCE) AS date_naissance FORMAT=DATE9., */
/* 		  		 DATEPART(DT_DECES) AS date_deces FORMAT=DATE9., */


/* 		  SELECT DATEPART(DT_NAISSANCE) AS date_naissance FORMAT=DATE9., */
/* 		  		 DATEPART(DT_DECES) AS date_deces FORMAT=DATE9., */
/* 		         TODAY() AS date_aujourdhui FORMAT=DATE9., */



