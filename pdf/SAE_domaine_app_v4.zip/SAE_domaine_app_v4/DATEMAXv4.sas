/* LIBNAME DONNEES "/home/u64203549/BUT SD/2�me ann�e/SAE_domaine_app_v3";   */
/* le path qui te rend au dossier o� il y a toutes les table de donn�es : CNR EDD   pour notre cas on utilise 4donnees */
%MACRO DATEMAX;
	
	LIBNAME DONNEES "&Chemin.";
	DATA donnees;
/*		SET DONNEES.&Perimetre.;*/
		SET DONNEES.donnees;
	RUN;		
	
	PROC SQL;
		CREATE TABLE Table_DATEMAX AS 
	    SELECT PUT(DATEPART(MAX(DT_DECES)), DATE9.) AS dateDecesMax
	    FROM donnees
	    WHERE date_survenance BETWEEN &Date_Debut. AND &Date_Fin.
	    AND DT_DECES IS NOT NULL;
	QUIT;
	
	PROC EXPORT DATA = Table_DATEMAX
	    OUTFILE="&&Repertoire&i../&&Cible&i..xlsx"
	    DBMS=XLSX
	    REPLACE;
	RUN;	

%MEND;


/*%DATEMAX(Chemin = Z:\IUT SD 2�me ann�e\SAE_domaine_app_v3,*/
/*	   Date_Debut = "3NOV2025"d,*/
/*	   Date_Fin = "16NOV2025"d,*/
/*	   Cible = tableDATEMAXv3,*/
/*	   Repertoire = Z:\IUT SD 2�me ann�e\SAE_domaine_app_v3\ResultatDraft*/
/*	   )*/




/*%DATEMAX(Chemin = Z:\IUT SD 2�me ann�e\SAE_domaine_app_v3,*/
/*	   Date_Debut = "3NOV2025"d,*/
/*	   Date_Fin = "16NOV2025"d,*/
/*	   Cible = tableDATEMAXv3,*/
/*	   Repertoire = Z:\IUT SD 2�me ann�e\SAE_domaine_app_v3\ResultatDraft,*/
/*	   Perimetre = donnees)*/

