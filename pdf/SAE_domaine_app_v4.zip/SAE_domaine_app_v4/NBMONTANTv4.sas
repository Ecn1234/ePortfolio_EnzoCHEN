/* LIBNAME DONNEES "/home/u64203549/BUT SD/2�me ann�e/SAE_domaine_app_v3";   */
/* le path qui te rend au dossier o� il y a toutes les table de donn�es : CNR EDD   pour notre cas on utilise 4donnees */
%MACRO NBMONTANT;
		
		LIBNAME DONNEES "&Chemin.";
		DATA donnees;
/*			SET DONNEES.&Perimetre.;*/
			SET DONNEES.donnees;
		RUN;	
		
		PROC SQL;
			SELECT COUNT(MNT_RESTANT_A_SOLDER) AS Nombre_Soldes_Nuls
			INTO : Nombre_Soldes_Nuls
			FROM donnees
			WHERE MNT_RESTANT_A_SOLDER = 0.00
			AND (date_survenance BETWEEN &Date_Debut. AND &Date_Fin.);
				
			SELECT COUNT(MNT_RESTANT_A_SOLDER) AS Nombre_Soldes_Non_Nuls
			INTO : Nombre_Soldes_Non_Nuls
			FROM donnees
			WHERE MNT_RESTANT_A_SOLDER <> 0.00 
			AND (date_survenance BETWEEN &Date_Debut. AND &Date_Fin.);
		QUIT;

		DATA Table_NBMONTANT;
		    Nombre_Soldes_Nuls = &Nombre_Soldes_Nuls.;
		    Nombre_Soldes_Non_Nuls = &Nombre_Soldes_Non_Nuls.;
		RUN;
		   
		
		PROC EXPORT DATA = Table_NBMONTANT
		    OUTFILE="&&Repertoire&i../&&Cible&i..xlsx"
		    DBMS=XLSX
		    REPLACE;
		RUN;	
%MEND;


/*%NBMONTANT( Chemin = Z:\IUT SD 2�me ann�e\SAE_domaine_app_v3 ,*/
/*		   Date_Debut = "3NOV2025"d,*/
/*		   Date_Fin = "16NOV2025"d,*/
/*		   Cible = tableNBMONTANTv3,*/
/*		   Repertoire = Z:\IUT SD 2�me ann�e\SAE_domaine_app_v3\ResultatDraft*/
/*			);*/





/*%NBMONTANT( Chemin = Z:\IUT SD 2�me ann�e\SAE_domaine_app_v3 ,*/
/*		   Date_Debut = "3NOV2025"d,*/
/*		   Date_Fin = "16NOV2025"d,*/
/*		   Cible = tableNBMONTANTv3,*/
/*		   Repertoire = Z:\IUT SD 2�me ann�e\SAE_domaine_app_v3\ResultatDraft,*/
/*		   Perimetre = donnees );*/


/* MethodeLongue */
/* 		PROC SQL; */
/* 			SELECT COUNT(MNT_RESTANT_A_SOLDER) AS Nombre_Soldes_Nuls */
/* 			FROM donnees */
/* 			WHERE MNT_RESTANT_A_SOLDER = 0.00 */
/* 			AND (date_survenance BETWEEN &Date_Debut. AND &Date_Fin.); */
/* 			 */
/* 			SELECT COUNT(MNT_RESTANT_A_SOLDER) AS Nombre_Soldes_Non_Nuls */
/* 			FROM donnees */
/* 			WHERE MNT_RESTANT_A_SOLDER <> 0.00  */
/* 			AND (date_survenance BETWEEN &Date_Debut. AND &Date_Fin.); */
/* 		QUIT; */
/*  */
/* 		DATA Table_NBMONTANT; */
/* 		    NbSolde0 = &NbSolde0.; */
/* 		    NbSoldeDiff0 = &NbSoldeDiff0.; */
/* 		RUN; */
		   



/* M�thodeCourte */


/* 		PROC SQL NOPRINT; */
/* 		    CREATE TABLE Table_NBMONTANT AS */
/* 		    SELECT  */
/* 		        SUM(CASE WHEN MNT_RESTANT_A_SOLDER = 0.00 THEN 1 ELSE 0 END) AS Nombre_Soldes_Nuls, */
/* 		        SUM(CASE WHEN MNT_RESTANT_A_SOLDER <> 0.00 THEN 1 ELSE 0 END) AS Nombre_Soldes_Non_Nuls */
/* 		    FROM donnees */
/* 		    WHERE date_survenance BETWEEN &Date_Debut. AND &Date_Fin.; */
/* 		QUIT; */






		   
		   
		   